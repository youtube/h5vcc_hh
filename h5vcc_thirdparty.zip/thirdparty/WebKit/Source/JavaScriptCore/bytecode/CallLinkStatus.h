/*
 * Copyright (C) 2012 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */

#ifndef CallLinkStatus_h
#define CallLinkStatus_h

namespace JSC {

class JSFunction;
class CodeBlock;

class CallLinkStatus {
public:
    CallLinkStatus()
        : m_callTarget(0)
        , m_couldTakeSlowPath(false)
    {
    }
    
    CallLinkStatus(JSFunction* callTarget, bool couldTakeSlowPath)
        : m_callTarget(callTarget)
        , m_couldTakeSlowPath(couldTakeSlowPath)
    {
    }
    
    static CallLinkStatus computeFor(CodeBlock*, unsigned bytecodeIndex);
    
    bool isSet() const { return !!m_callTarget || m_couldTakeSlowPath; }
    
    bool operator!() const { return !isSet(); }
    
    bool couldTakeSlowPath() const { return m_couldTakeSlowPath; }
    
    JSFunction* callTarget() const { return m_callTarget; }
    
private:
    static CallLinkStatus computeFromLLInt(CodeBlock*, unsigned bytecodeIndex);
    
    JSFunction* m_callTarget;
    bool m_couldTakeSlowPath;
};

} // namespace JSC

#endif // CallLinkStatus_h

